import java.io.File;
import java.io.IOException;

public class StringTable extends Element {
    public String string;
    public int offset;

    public StringTable(File file) throws IOException {
        super(file);
    }

    @Override
    void read() throws IOException {
        StringBuilder sb = new StringBuilder();
        int cur = readByte();
        offset++;
        while (cur != 0x0) {
            sb.append((char) (cur));
            cur = readByte();
            offset++;
        }
        string = sb.toString();
    }

    @Override
    void dump() {
        System.out.println(string);
        System.out.println();
    }
}
