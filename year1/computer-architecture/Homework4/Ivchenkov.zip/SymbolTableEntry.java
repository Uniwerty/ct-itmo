public class SymbolTableEntry {
    public int st_name;
    public int st_value;
    public int st_size;
    public int st_info;
    public int st_other;
    public int st_shndx;
    public int st_type;
    public int st_vis;
    public int st_bind;
    public String name;
}
