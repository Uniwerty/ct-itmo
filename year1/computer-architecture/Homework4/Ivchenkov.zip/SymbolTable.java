import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SymbolTable extends Element {
    public List<SymbolTableEntry> table;
    public final int numberOfEntries;

    public SymbolTable(File file, int numberOfEntries) throws IOException {
        super(file);
        table = new ArrayList<>();
        this.numberOfEntries = numberOfEntries;
    }

    @Override
    void read() throws IOException {
        for (int i = 0; i < numberOfEntries; i++) {
            table.add(readEntry());
        }
    }

    private SymbolTableEntry readEntry() throws IOException {
        SymbolTableEntry entry = new SymbolTableEntry();
        entry.st_name = readWord();
        entry.st_value = readWord();
        entry.st_size = readWord();
        entry.st_info = readByte();
        entry.st_other = readByte();
        entry.st_shndx = readHalfWord();
        entry.st_type = entry.st_info & 0xf;
        entry.st_vis = entry.st_other & 0x3;
        entry.st_bind = entry.st_info >>> 4;
        return entry;
    }

    @Override
    void dump() {
        for (int i = 0; i < numberOfEntries; i++) {
            System.out.printf("%s %d %n", "Entry ", i + 1);
            System.out.printf("%-8s %08x %n", "st_name", table.get(i).st_name);
            System.out.printf("%-8s %08x %n", "st_value", table.get(i).st_value);
            System.out.printf("%-8s %08x %n", "st_size", table.get(i).st_size);
            System.out.printf("%-8s %02x %n", "st_info", table.get(i).st_info);
            System.out.printf("%-8s %02x %n", "st_other", table.get(i).st_other);
            System.out.printf("%-8s %04x %n", "st_shndx", table.get(i).st_shndx);
            System.out.printf("%-8s %04x %n", "st_type", table.get(i).st_type);
            System.out.printf("%-8s %04x %n", "St_vis", table.get(i).st_vis);
            System.out.printf("%-8s %04x %n", "st_bind", table.get(i).st_bind);
            System.out.println();
        }
    }
}
