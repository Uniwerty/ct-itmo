import java.io.File;
import java.io.IOException;

public class SectionHeader extends Element {
    public int sh_name;
    public int sh_type;
    public int sh_flags;
    public int sh_addr;
    public int sh_offset;
    public int sh_size;
    public int sh_link;
    public int sh_info;
    public int sh_addralign;
    public int sh_entsize;

    public SectionHeader(File file) throws IOException {
        super(file);
    }

    @Override
    public void read() throws IOException {
        sh_name = readWord();
        sh_type = readWord();
        sh_flags = readWord();
        sh_addr = readWord();
        sh_offset = readWord();
        sh_size = readWord();
        sh_link = readWord();
        sh_info = readWord();
        sh_addralign = readWord();
        sh_entsize = readWord();
    }

    @Override
    public void dump() {
        System.out.printf("%-12s %08x %n", "sh_name", sh_name);
        System.out.printf("%-12s %08x %n", "sh_type", sh_type);
        System.out.printf("%-12s %08x %n", "sh_flags", sh_flags);
        System.out.printf("%-12s %08x %n", "sh_addr", sh_addr);
        System.out.printf("%-12s %08x %n", "sh_offset", sh_offset);
        System.out.printf("%-12s %08x %n", "sh_size", sh_size);
        System.out.printf("%-12s %08x %n", "sh_link", sh_link);
        System.out.printf("%-12s %08x %n", "sh_info", sh_info);
        System.out.printf("%-12s %08x %n", "sh_addralign", sh_addralign);
        System.out.printf("%-12s %08x %n", "sh_entsize", sh_entsize);
        System.out.println();
    }
}
