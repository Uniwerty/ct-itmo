import java.io.*;

public class hw4 {
    public static void main(String[] args) {
        try {
            Disassembler d = new Disassembler(new ElfFile(args[0]));
            d.disassemble(args[1]);
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
