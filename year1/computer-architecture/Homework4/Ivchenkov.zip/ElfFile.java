import java.io.*;

public class ElfFile {
    public final File source;
    public ElfHeader elfHeader;
    public SectionHeader shstrtabHeader;
    public SectionHeader textHeader;
    public SymbolTable symbolTable;
    public SectionHeader symtabHeader;
    public SectionHeader strtabHeader;
    public StringTable stringTable;

    public ElfFile(String filename) throws IOException {
        source = new File(filename);
        readElfHeader();
        readShstrtabHeader();
        readTextHeader();
        readStrtabHeader();
        readSymbolTable();
    }

    private void readStrtabHeader() throws IOException {
        // Finding .strtab string in .shstrtab
        StringTable shstrTable = new StringTable(source);
        shstrTable.reader.skip(shstrtabHeader.sh_offset);
        shstrTable.read();
        while (!shstrTable.string.equals(".strtab")) {
            shstrTable.read();
        }
        // Setting offset on the beginning of .strtab
        shstrTable.offset -= 8;
        // Finding and reading .strtab Header
        strtabHeader = new SectionHeader(source);
        strtabHeader.reader.skip(elfHeader.e_shoff);
        while (strtabHeader.sh_name != shstrTable.offset) {
            strtabHeader.read();
        }
    }

    private void readSymbolTable() throws IOException {
        // Finding and reading .symtab Header
        symtabHeader = new SectionHeader(source);
        symtabHeader.reader.skip(elfHeader.e_shoff);
        while (symtabHeader.sh_type != 0x2) {
            symtabHeader.read();
        }
        // Reading .symtab
        symbolTable = new SymbolTable(source, symtabHeader.sh_size / symtabHeader.sh_entsize);
        symbolTable.reader.skip(symtabHeader.sh_offset);
        symbolTable.read();
        // Reading names of labels
        for (int i = 0; i < symbolTable.table.size(); i++) {
            stringTable = new StringTable(source);
            stringTable.reader.skip(strtabHeader.sh_offset + symbolTable.table.get(i).st_name);
            stringTable.read();
            symbolTable.table.get(i).name = stringTable.string;
        }
    }

    private void readTextHeader() throws IOException {
        // Finding .text string in .shstrtab
        StringTable shstrTable = new StringTable(source);
        shstrTable.reader.skip(shstrtabHeader.sh_offset);
        shstrTable.read();
        while (!shstrTable.string.equals(".text")) {
            shstrTable.read();
        }
        // Setting offset on the beginning of .text
        shstrTable.offset -= 6;
        // Finding and reading .text Header
        textHeader = new SectionHeader(source);
        textHeader.reader.skip(elfHeader.e_shoff);
        while (textHeader.sh_name != shstrTable.offset) {
            textHeader.read();
        }
    }

    private void readShstrtabHeader() throws IOException {
        // Reading .shstrtab Header
        shstrtabHeader = new SectionHeader(source);
        shstrtabHeader.reader.skip(elfHeader.e_shoff + (long) elfHeader.e_shentsize * elfHeader.e_shstrndx);
        shstrtabHeader.read();
    }

    private void readElfHeader() throws IOException {
        // Reading ELF Header
        elfHeader = new ElfHeader(source);
        elfHeader.read();
        // Checking file correctness
        elfHeader.check();
    }

    public void closeAll() throws IOException {
        elfHeader.reader.close();
        shstrtabHeader.reader.close();
        textHeader.reader.close();
        symbolTable.reader.close();
        symtabHeader.reader.close();
        strtabHeader.reader.close();
        stringTable.reader.close();
    }
}
