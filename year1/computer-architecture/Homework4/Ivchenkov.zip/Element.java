import java.io.*;

public abstract class Element {
    public final File file;
    public final BufferedInputStream reader;

    public Element(File file) throws IOException {
        this.file = file;
        this.reader = new BufferedInputStream(new FileInputStream(file));
    }

    abstract void read() throws IOException;

    abstract void dump();

    protected int readByte() throws IOException {
        return reader.read();
    }

    protected int readHalfWord() throws IOException {
        return reader.read() + reader.read() * 0x100;
    }

    protected int readWord() throws IOException {
        return reader.read() + reader.read() * 0x100 + reader.read() * 0x10000 + reader.read() * 0x1000000;
    }
}
