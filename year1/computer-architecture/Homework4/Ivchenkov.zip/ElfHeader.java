import java.io.File;
import java.io.IOException;

public class ElfHeader extends Element {
    public int [] e_ident;
    public int e_type;
    public int e_machine;
    public int e_version;
    public int e_entry;
    public int e_phoff;
    public int e_shoff;
    public int e_flags;
    public int e_ehsize;
    public int e_phentsize;
    public int e_phnum;
    public int e_shentsize;
    public int e_shnum;
    public int e_shstrndx;

    public ElfHeader(File file) throws IOException {
        super(file);
    }

    @Override
    public void read() throws IOException {
        e_ident = new int[16];
        for (int i = 0; i < 16; i++) {
            e_ident[i] = readByte();
        }
        e_type = readHalfWord();
        e_machine = readHalfWord();
        e_version = readWord();
        e_entry = readWord();
        e_phoff = readWord();
        e_shoff = readWord();
        e_flags = readWord();
        e_ehsize = readHalfWord();
        e_phentsize = readHalfWord();
        e_phnum = readHalfWord();
        e_shentsize = readHalfWord();
        e_shnum = readHalfWord();
        e_shstrndx = readHalfWord();
    }

    public void check() throws IOException {
        if (e_ident[0] != 0x7f || e_ident[1] != 0x45 || e_ident[2] != 0x4c || e_ident[3] != 0x46) {
            throw new IOException("Illegal file");
        }
        if (e_ident[4] != 0x01) {
            throw new IOException("File is not 32 bit");
        }
        if (e_ident[5] != 0x01) {
            throw new IOException("File is not little-endian");
        }
        if (e_machine != 0xF3) {
            throw new IOException("File architecture is not RISC-V");
        }
    }

    @Override
    public void dump() {
        System.out.printf("%-12s ", "e_ident");
        for (int i = 0; i < 16; i++) {
            System.out.printf("%02x ", e_ident[i]);
        }
        System.out.println();
        System.out.printf("%-12s %02x %n", "e_type", e_type);
        System.out.printf("%-12s %02x %n", "e_machine", e_machine);
        System.out.printf("%-12s %04x %n", "e_version", e_version);
        System.out.printf("%-12s %04x %n", "e_entry", e_entry);
        System.out.printf("%-12s %04x %n", "e_phoff", e_phoff);
        System.out.printf("%-12s %04x %n", "e_shoff", e_shoff);
        System.out.printf("%-12s %04x %n", "e_flags", e_flags);
        System.out.printf("%-12s %02x %n", "e_ehsize", e_ehsize);
        System.out.printf("%-12s %02x %n", "e_phentsize", e_phentsize);
        System.out.printf("%-12s %02x %n", "e_phnum", e_phnum);
        System.out.printf("%-12s %02x %n", "e_shentsize", e_shentsize);
        System.out.printf("%-12s %02x %n", "e_shnum", e_shnum);
        System.out.printf("%-12s %02x %n", "e_shstrndx", e_shstrndx);
        System.out.println();
    }
}
