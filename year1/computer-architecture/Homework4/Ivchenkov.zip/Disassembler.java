import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Disassembler {
    private final ElfFile file;
    private int address;
    private int byteNumber;
    private BufferedInputStream reader;
    private final Map<Integer, String> labels;
    private final Map<Integer, String> jumps;
    private static final String[] REGISTERS = new String[] {
            "zero", "ra", "sp", "gp", "tp", "t0", "t1", "t2",
            "s0", "s1", "a0", "a1", "a2", "a3", "a4", "a5",
            "a6", "a7", "s2", "s3", "s4", "s5", "s6", "s7",
            "s8", "s9", "s10", "s11", "t3", "t4", "t5", "t6"
    };

    public Disassembler(ElfFile file) throws IOException {
        this.file = file;
        this.address = file.textHeader.sh_addr;
        this.byteNumber = 0;
        this.labels = new HashMap<>();
        markLabels();
        // Mark jumps
        this.reader = new BufferedInputStream(new FileInputStream(file.source));
        this.reader.skip(file.textHeader.sh_offset);
        this.jumps = new HashMap<>();
        markJumps();
        reader.close();
        // Making ready to disassemble
        this.address = file.textHeader.sh_addr;
        this.byteNumber = 0;
        this.reader = new BufferedInputStream(new FileInputStream(file.source));
        this.reader.skip(file.textHeader.sh_offset);
    }

    public void disassemble(String filename) {
        try (BufferedWriter writer =
                     new BufferedWriter(
                             new OutputStreamWriter(
                                     new FileOutputStream(
                                             filename
                                     ),
                                     StandardCharsets.UTF_8
                             )
                     )
        ) {
            writer.write(".text");
            writer.write(System.lineSeparator());
            writer.write(writeTextSection());
            writer.write(System.lineSeparator());
            writer.write(".symtab");
            writer.write(System.lineSeparator());
            writer.write(writeSymbolTable());
            reader.close();
            file.closeAll();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private String writeTextSection() throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        boolean previousReceived = true;
        int previousCode = 0;
        while (byteNumber < file.textHeader.sh_size) {
            String label = getLabel(address);
            int currentCode = read16bit();
            if (previousReceived) {
                // Checking current 16bit code
                String instruction = get16bitInstruction(currentCode);
                if (!instruction.equals("unknown_command")) {
                    if (isJumpInstruction(currentCode)) {
                        label = "";
                    }
                    stringBuilder.append(writeInstruction(label, instruction));
                    stringBuilder.append(System.lineSeparator());
                    address += 2;
                    byteNumber += 2;
                } else {
                    previousCode = currentCode;
                    previousReceived = false;
                }
            } else {
                // Checking all 32bit code
                int code = previousCode + currentCode * 0x10000;
                String instruction = get32bitInstruction(code);
                if (!instruction.equals("unknown_command")) {
                    if (isJumpInstruction(code)) {
                        label = "";
                    }
                    stringBuilder.append(writeInstruction(label, instruction));
                    stringBuilder.append(System.lineSeparator());
                    address += 4;
                    byteNumber += 4;
                    previousReceived = true;
                } else {
                    // Writing previous 16bit code
                    stringBuilder.append(writeInstruction(label, "unknown_command"));
                    stringBuilder.append(System.lineSeparator());
                    address += 2;
                    byteNumber += 2;
                    label = getLabel(address);
                    // Checking current 16bit code
                    instruction = get16bitInstruction(currentCode);
                    if (!instruction.equals("unknown_command")) {
                        if (isJumpInstruction(currentCode)) {
                            label = "";
                        }
                        stringBuilder.append(writeInstruction(label, instruction));
                    } else {
                        stringBuilder.append(writeInstruction(label, "unknown_command"));
                    }
                    stringBuilder.append(System.lineSeparator());
                    previousReceived = true;
                    address += 2;
                    byteNumber += 2;
                }
            }
        }
        return stringBuilder.toString();
    }

    private String writeInstruction(String label, String instruction) {
        if (label.length() != 0) {
            return String.format("%08x %10s: %s", address, label, instruction);
        } else {
            return String.format("%08x %10s  %s", address, label, instruction);
        }
    }

    private String writeSymbolTable() {
        StringBuilder stringBuilder = new StringBuilder();
        final List<SymbolTableEntry> table = file.symbolTable.table;
        stringBuilder.append(String.format(
                        "%s %-15s %7s %-8s %-8s %-8s %6s %s\n",
                        "Symbol", "Value", "Size", "Type", "Bind", "Vis", "Index", "Name"
                )
        );
        for (int i = 0; i < file.symbolTable.numberOfEntries; i++) {
            String type = switch(table.get(i).st_type) {
                case 0 -> "NOTYPE";
                case 1 -> "OBJECT";
                case 2 -> "FUNC";
                case 3 -> "SECTION";
                case 4 -> "FILE";
                case 13 -> "LOPROC";
                case 15 -> "HIPROC";
                default -> null;
            };
            String bind = switch(table.get(i).st_bind) {
                case 0 -> "LOCAL";
                case 1 -> "GLOBAL";
                case 2 -> "WEAK";
                case 13 -> "LOPROC";
                case 15 -> "HIPROC";
                default -> null;
            };
            String vis = switch(table.get(i).st_vis) {
                case 0 -> "DEFAULT";
                case 1 -> "INTERNAL";
                case 2 -> "HIDDEN";
                case 3 -> "PROTECTED";
                case 4 -> "EXPORTED";
                case 5 -> "SINGLETON";
                case 6 -> "ELIMINATE";
                default -> null;
            };
            String index = switch(table.get(i).st_shndx) {
                case 0 -> "UNDEF";
                case 0xff00 -> "LORESERVE";
                case 0xff1f -> "HIPROC";
                case 0xfff1 -> "ABS";
                case 0xfff2 -> "COMMON";
                case 0xffff -> "HIRESERVE";
                default -> String.valueOf(table.get(i).st_shndx);
            };
            stringBuilder.append(String.format(
                            "[%4d] 0x%-15X %5d %-8s %-8s %-8s %6s %s\n",
                            i, table.get(i).st_value, table.get(i).st_size, type, bind, vis, index, table.get(i).name
                    )
            );
        }
        return stringBuilder.toString();
    }

    private void markLabels() {
        for (int i = 0; i < file.symbolTable.table.size(); i++) {
            // Finding FUNC entries
            if (file.symbolTable.table.get(i).st_type == 2) {
                labels.put(file.symbolTable.table.get(i).st_value, file.symbolTable.table.get(i).name);
            }
        }
    }

    private String getLabel(int addr) {
        if (labels.containsKey(addr)) {
            if (labels.get(addr).length() != 0) {
                return labels.get(addr);
            } else {
                return String.format("LOC_%05x", addr);
            }
        } else {
            return "";
        }
    }

    private void markJumps() throws IOException {
        boolean previousReceived = true;
        int previousCode = 0;
        int labelNumber = 0;
        while (byteNumber < file.textHeader.sh_size) {
            int currentCode = read16bit();
            if (previousReceived) {
                // Checking current 16bit code
                if (isJumpInstruction(currentCode)) {
                    int jumpAddress = address + getJumpOffset(currentCode);
                    if (!labels.containsKey(jumpAddress)) {
                        labels.put(jumpAddress, String.format("LOC_%05x", labelNumber));
                    }
                    jumps.put(address, labels.get(jumpAddress));
                    labelNumber++;
                    address += 2;
                    byteNumber += 2;
                } else {
                    previousCode = currentCode;
                    previousReceived = false;
                }
            } else {
                // Checking all 32bit code
                int code = previousCode + currentCode * 0x10000;
                if (isJumpInstruction(code)) {
                    int jumpAddress = address + getJumpOffset(code);
                    if (!labels.containsKey(jumpAddress)) {
                        labels.put(jumpAddress, String.format("LOC_%05x", labelNumber));
                    }
                    jumps.put(address, labels.get(jumpAddress));
                    labelNumber++;
                    address += 4;
                    byteNumber += 4;
                    previousReceived = true;
                } else {
                    address += 2;
                    byteNumber += 2;
                    // Checking current 16bit code
                    if (isJumpInstruction(currentCode)) {
                        int jumpAddress = address + getJumpOffset(currentCode);
                        if (!labels.containsKey(jumpAddress)) {
                            labels.put(jumpAddress, String.format("LOC_%05x", labelNumber));
                        }
                        jumps.put(address, labels.get(jumpAddress));
                        labelNumber++;
                    }
                    previousReceived = true;
                    address += 2;
                    byteNumber += 2;
                }
            }
        }
    }

    private boolean isJumpInstruction(int instruction) {
        int opcode = instruction << 25 >>> 25;
        if (opcode == 0b1101111) {
            // JAL
            return true;
        } else if (opcode == 0b1100011) {
            // BEQ BNE BLT BGE BLTU BGEU
            return true;
        }
        int op = instruction << 14 >>> 14;
        int func3 = instruction >>> 13;
        if (op == 0b01) {
            if (func3 == 0b001 || func3 == 0b101) {
                // C.JAL C.J
                return true;
            } else if (func3 == 0b110 || func3 == 0b111) {
                // C.BEQZ C.BNEZ
                return true;
            }
        }
        return false;
    }

    private int getJumpOffset(int instruction) {
        int opcode = instruction << 25 >>> 25;
        if (opcode == 0b1101111) {
            // JAL
            return (instruction << 1 >>> 22) * 0b10 +
                    (instruction << 11 >>> 31) * 0b100000000000 +
                    (instruction << 12 >>> 24) * 0b1000000000000 +
                    (instruction >>> 31) * 0b100000000000000000000;
        } else if (opcode == 0b1100011) {
            // BEQ BNE BLT BGE BLTU BGEU
            return (instruction << 20 >>> 28) * 0b10 +
                    (instruction << 1 >>> 26) * 0b100000 +
                    (instruction << 24 >>> 31) * 0b100000000000 +
                    (instruction >>> 31) * 0b1000000000000;
        }
        int op = instruction << 14 >>> 14;
        int func3 = instruction >>> 13;
        if (op == 0b01) {
            if (func3 == 0b001 || func3 == 0b101) {
                // C.JAL C.J
                return (instruction << 10 >>> 13) * 0b10 +
                        (instruction << 4 >>> 15) * 0b10000 +
                        (instruction << 13 >>> 15) * 0b100000 +
                        (instruction << 8 >>> 15) * 0b1000000 +
                        (instruction << 9 >>> 15) * 0b10000000 +
                        (instruction << 5 >>> 14) * 0b100000000 +
                        (instruction << 7 >>> 15) * 0b10000000000 +
                        (instruction << 3 >>> 15) * 0b100000000000;
            } else if (func3 == 0b110 || func3 == 0b111) {
                // C.BEQZ C.BNEZ
                return (instruction << 11 >>> 14) * 0b10 +
                        (instruction << 4 >>> 14) * 0b1000 +
                        (instruction << 13 >>> 15) * 0b100000 +
                        (instruction << 9 >>> 14) * 0b1000000 +
                        (instruction << 3 >>> 15) * 0b100000000;
            }
        }
        return 0;
    }

    private String get16bitInstruction(int instruction) {
        int op = instruction << 14 >>> 14;
        int func3 = instruction >>> 13;
        if (op == 0b00) {
            int rdc = instruction << 11 >>> 13;
            int rs2c = rdc;
            int rs1c = instruction << 6 >>> 13;
            long uimm = ((long) instruction << 9 >>> 15) +
                    ((long) instruction << 3 >>> 13) * 0b10 +
                    ((long) instruction << 10 >>> 15) * 0b10000;
            if (func3 == 0b000) {
                // C.ADDI4SPN
                long nzuimm = ((long) instruction << 9 >>> 15) +
                        ((long) instruction << 10 >>> 15) * 0b10 +
                        ((long) instruction << 3 >>> 14) * 0b100 +
                        ((long) instruction << 5 >>> 12) * 0b10000;
                if (nzuimm != 0) {
                    return String.format("%s %s, %s, %s", "c.addi4spn", getC_Register(rdc), "sp", nzuimm);
                }
            } else if (func3 == 0b010) {
                // C.LW
                return String.format("%s %s, %s, %s", "c.lw", getC_Register(rdc), getC_Register(rs1c), uimm);
            } else if (func3 == 0b110) {
                // C.SW
                return String.format("%s %s, %s, %s", "c.sw", getC_Register(rs2c), getC_Register(rs1c), uimm);
            }
        } else if (op == 0b01) {
            if (func3 == 0b000) {
                // C.ADDI
                int nzimm = (instruction << 9 >>> 11) +
                        (instruction << 3 >>> 15) * 0b100000;
                int rd = instruction << 4 >>> 11;
                if (rd != 0 && nzimm != 0) {
                    return String.format("%s %s, %s", "c.addi", getRegister(rd), nzimm);
                }
            } else if (func3 == 0b001) {
                // C.JAL
                int imm = (instruction << 10 >>> 13) +
                        (instruction << 4 >>> 15) * 0b1000 +
                        (instruction << 13 >>> 15) * 0b10000 +
                        (instruction << 8 >>> 15) * 0b100000 +
                        (instruction << 9 >>> 15) * 0b1000000 +
                        (instruction << 5 >>> 14) * 0b10000000 +
                        (instruction << 7 >>> 15) * 0b1000000000 +
                        (instruction << 3 >>> 15) * 0b10000000000;
                return String.format("%s %s, %s", "c.jal", imm, jumps.get(address));
            } else if (func3 == 0b010) {
                // C.LI
                int imm = (instruction << 9 >>> 11) +
                        (instruction << 3 >>> 15) * 0b100000;
                int rd = instruction << 4 >>> 11;
                if (rd != 0) {
                    return String.format("%s %s, %s", "c.li", getRegister(rd), imm);
                }
            } else if (func3 == 0b011) {
                int rd = instruction << 4 >>> 11;
                int nzimm;
                if (rd == 2) {
                    // C.ADDI16SP
                    nzimm = (instruction << 9 >>> 15) +
                            (instruction << 13 >>> 15) * 0b10 +
                            (instruction << 10 >>> 15) * 0b100 +
                            (instruction << 11 >>> 14) * 0b1000 +
                            (instruction << 3 >>> 15) * 0b100000;
                    if (nzimm != 0) {
                        return String.format("%s %s, %s", "c.addi16sp", "sp", nzimm);
                    }
                } else if (rd != 0){
                    // C.LUI
                    nzimm = (instruction << 9 >>> 11) +
                            (instruction << 3 >>> 15) * 0b1000000;
                    if (nzimm != 0) {
                        return String.format("%s %s, %s", "c.lui", getRegister(rd), nzimm);
                    }
                }
            } else if (func3 == 0b100) {
                // C.SRLI C.SRAI C.ANDI C.SUB C.XOR C.OR C.AND
                int func2 = instruction << 4 >>> 14;
                int func6 = instruction >>> 10;
                int rdc = instruction << 6 >>> 13;
                long nzuimm = ((long) instruction << 9 >>> 11) +
                        ((long) instruction << 3 >>> 15) * 0b100000;
                int imm = ( instruction << 9 >>> 11) +
                        (instruction << 3 >>> 15) * 0b100000;
                if (func2 == 0b00) {
                    // C.SRLI
                    if (nzuimm != 0) {
                        return String.format("%s %s, %s", "c.srli", getC_Register(rdc), nzuimm);
                    }
                } else if (func2 == 0b01) {
                    // C.SRAI
                    if (nzuimm != 0) {
                        return String.format("%s %s, %s", "c.srai", getC_Register(rdc), nzuimm);
                    }
                } else if (func2 == 0b10) {
                    // C.ANDI
                    return String.format("%s %s, %s", "c.andi", getC_Register(rdc), imm);
                } else if (func6 == 0b100011) {
                    int rs2c = instruction << 11 >>> 13;
                    func2 = instruction << 9 >>> 14;
                    if (func2 == 0b00) {
                        // C.SUB
                        return String.format("%s %s, %s", "c.sub", getC_Register(rdc), getC_Register(rs2c));
                    } else if (func2 == 0b01) {
                        // C.XOR
                        return String.format("%s %s, %s", "c.xor", getC_Register(rdc), getC_Register(rs2c));
                    } else if (func2 == 0b10) {
                        // C.OR
                        return String.format("%s %s, %s", "c.or", getC_Register(rdc), getC_Register(rs2c));
                    } else if (func2 == 0b11) {
                        // C.AND
                        return String.format("%s %s, %s", "c.and", getC_Register(rdc), getC_Register(rs2c));
                    }
                }
            } else if (func3 == 0b101) {
                // C.J
                int imm = (instruction << 10 >>> 13) +
                        (instruction << 4 >>> 15) * 0b1000 +
                        (instruction << 13 >>> 15) * 0b10000 +
                        (instruction << 8 >>> 15) * 0b100000 +
                        (instruction << 9 >>> 15) * 0b1000000 +
                        (instruction << 5 >>> 14) * 0b10000000 +
                        (instruction << 7 >>> 15) * 0b1000000000 +
                        (instruction << 3 >>> 15) * 0b10000000000;
                return String.format("%s %s, %s", "c.j", imm, jumps.get(address));
            } else if (func3 == 0b110) {
                // C.BEQZ
                int rs1c = instruction << 6 >>> 13;
                int imm = (instruction << 11 >>> 14) +
                        (instruction << 4 >>> 14) * 0b100 +
                        (instruction << 13 >>> 15) * 0b10000 +
                        (instruction << 9 >>> 14) * 0b100000 +
                        (instruction << 3 >>> 15) * 0b10000000;
                return String.format("%s %s, %s, %s", "c.beqz", getC_Register(rs1c), imm, jumps.get(address));
            } else if (func3 == 0b111) {
                // C.BNEZ
                int rs1c = instruction << 6 >>> 13;
                int imm = (instruction << 11 >>> 14) +
                        (instruction << 4 >>> 14) * 0b100 +
                        (instruction << 13 >>> 15) * 0b10000 +
                        (instruction << 9 >>> 14) * 0b100000 +
                        (instruction << 3 >>> 15) * 0b10000000;
                return String.format("%s %s, %s, %s", "c.bnez", getC_Register(rs1c), imm, jumps.get(address));
            }
        } else if (op == 0b10) {
            int rd = instruction << 4 >>> 11;
            int rs1 = rd;
            if (func3 == 0b000) {
                // C.SLLI
                long nzuimm = ((long) instruction << 9 >>> 11) +
                        ((long) instruction << 3 >>> 15) * 0b100000;
                if (nzuimm != 0 && rd != 0) {
                    return String.format("%s %s, %s", "c.slli", getRegister(rd), nzuimm);
                }
            } else if (func3 == 0b010) {
                // C.LWSP
                long uimm = ((long) instruction << 9 >>> 13) +
                        ((long) instruction << 3 >>> 15) * 0b1000 +
                        ((long) instruction << 12 >>> 14) * 0b10000;
                if (rd != 0) {
                    return String.format("%s %s, %s", "c.lwsp", getRegister(rd), uimm);
                }
            } else if (func3 == 0b100) {
                // C.JR C.MV C.EBREAK C.JALR C.ADD
                int rs2 = instruction << 9 >>> 11;
                int func4 = instruction >>> 12;
                if (func4 == 0b1000 && rd != 0) {
                    if (rs2 == 0) {
                        // C.JR
                        return String.format("%s %s", "c.jr", getRegister(rs1));
                    } else {
                        // C.MV
                        return String.format("%s %s, %s", "c.mv", getRegister(rd), getRegister(rs2));
                    }
                } else if (func4 == 0b1001) {
                    if (rs2 == 0) {
                        if (rs1 == 0) {
                            // C.EBREAK
                            return "c.ebreak";
                        } else {
                            // C.JALR
                            return String.format("%s %s", "c.jalr", getRegister(rs1));
                        }
                    } else if (rd != 0) {
                        // C.ADD
                        return String.format("%s %s, %s", "c.add", getRegister(rd), getRegister(rs2));
                    }
                }
            } else if (func3 == 0b110) {
                // C.SWSP
                int rs2 = instruction << 9 >>> 11;
                long uimm = ((long) instruction << 3 >>> 12) +
                        ((long) instruction << 7 >>> 14) * 0b10000;
                return String.format("%s %s, %s", "c.swsp", getRegister(rs2), uimm);
            }
        }
        return "unknown_command";
    }

    private String get32bitInstruction(int instruction) {
        int opcode = instruction << 25 >>> 25;
        if (opcode == 0b0110111) {
            // LUI
            int rd = instruction << 20 >>> 27;
            int imm = instruction >>> 12;
            return String.format("%s %s, %s", "lui", getRegister(rd), imm);
        } else if (opcode == 0b0010111) {
            // AUIPC
            int rd = instruction << 20 >>> 27;
            int imm = instruction >>> 12;
            return String.format("%s %s, %s", "auipc", getRegister(rd), imm);
        } else if (opcode == 0b1101111) {
            // JAL
            int rd = instruction << 20 >>> 27;
            int imm = (instruction << 1 >>> 22) +
                    (instruction << 11 >>> 31) * 0b10000000000 +
                    (instruction << 12 >>> 24) * 0b100000000000 +
                    (instruction >>> 31) * 0b10000000000000000000;
            return String.format("%s %s, %s, %s", "jal", getRegister(rd), imm, jumps.get(address));
        } else if (opcode == 0b1100111) {
            // JALR
            int rd = instruction << 20 >>> 27;
            int rs1 = instruction << 12 >>> 27;
            int imm = instruction >>> 20;
            return String.format("%s %s, %s", "jalr", getRegister(rd), getRegister(rs1), imm);
        } else if (opcode == 0b1100011) {
            // BEQ BNE BLT BGE BLTU BGEU
            int rs1 = instruction << 12 >>> 27;
            int rs2 = instruction << 7 >>> 27;
            int imm = (instruction << 20 >>> 28) +
                    (instruction << 1 >>> 26) * 0b10000 +
                    (instruction << 24 >>> 31) * 0b10000000000 +
                    (instruction >>> 31) * 0b100000000000;
            int func3 = instruction << 17 >>> 29;
            return switch(func3) {
                case 0b000 -> String.format("%s %s, %s, %s, %s", "beq", getRegister(rs1), getRegister(rs2), imm, jumps.get(address)); // BEQ
                case 0b001 -> String.format("%s %s, %s, %s, %s", "bne", getRegister(rs1), getRegister(rs2), imm, jumps.get(address)); // BNE
                case 0b100 -> String.format("%s %s, %s, %s, %s", "blt", getRegister(rs1), getRegister(rs2), imm, jumps.get(address)); // BLT
                case 0b101 -> String.format("%s %s, %s, %s, %s", "bge", getRegister(rs1), getRegister(rs2), imm, jumps.get(address)); // BGE
                case 0b110 -> String.format("%s %s, %s, %s, %s", "bltu", getRegister(rs1), getRegister(rs2), imm, jumps.get(address)); // BLTU
                case 0b111 -> String.format("%s %s, %s, %s, %s", "bgeu", getRegister(rs1), getRegister(rs2), imm, jumps.get(address)); // BGEU
                default -> "unknown_command";
            };
        } else if (opcode == 0b0000011) {
            // LB LH LW LBU LHU
            int rd = instruction << 20 >>> 27;
            int rs1 = instruction << 12 >>> 27;
            int imm = instruction >>> 20;
            int func3 = instruction << 17 >>> 29;
            return switch(func3) {
                case 0b000 -> String.format("%s %s, %s(%s)", "lb", getRegister(rd), imm, getRegister(rs1)); // LB
                case 0b001 -> String.format("%s %s, %s(%s)", "lh", getRegister(rd), imm, getRegister(rs1)); // LH
                case 0b010 -> String.format("%s %s, %s(%s)", "lw", getRegister(rd), imm, getRegister(rs1)); // LW
                case 0b100 -> String.format("%s %s, %s(%s)", "lbu", getRegister(rd), imm, getRegister(rs1)); // LBU
                case 0b101 -> String.format("%s %s, %s(%s)", "lhu", getRegister(rd), imm, getRegister(rs1)); // LHU
                default -> "unknown_command";
            };
        } else if (opcode == 0b0100011) {
            // SB SH SW
            int rs1 = instruction << 12 >>> 27;
            int rs2 = instruction << 7 >>> 27;
            int imm = (instruction << 20 >>> 27) +
                    (instruction >>> 25) * 0b100000;
            int func3 = instruction << 17 >>> 29;
            return switch(func3) {
                case 0b000 -> String.format("%s %s, %s(%s)", "sb", getRegister(rs2), imm, getRegister(rs1)); // SB
                case 0b001 -> String.format("%s %s, %s(%s)", "sh", getRegister(rs2), imm, getRegister(rs1)); // SH
                case 0b010 -> String.format("%s %s, %s(%s)", "sw", getRegister(rs2), imm, getRegister(rs1)); // SW
                default -> "unknown_command";
            };
        } else if (opcode == 0b0010011) {
            // ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI
            int rd = instruction << 20 >>> 27;
            int rs1 = instruction << 12 >>> 27;
            int func3 = instruction << 17 >>> 29;
            int imm = instruction >>> 20;
            int shamt = instruction << 7 >>> 27;
            int func7 = instruction >>> 25;
            if (func3 == 0b000) {
                // ADDI
                return String.format("%s %s, %s, %s", "addi", getRegister(rd), getRegister(rs1), imm);
            } else if (func3 == 0b010) {
                // SLTI
                return String.format("%s %s, %s, %s", "slti", getRegister(rd), getRegister(rs1), imm);
            } else if (func3 == 0b011) {
                // SLTIU
                return String.format("%s %s, %s, %s", "sltiu", getRegister(rd), getRegister(rs1), imm);
            } else if (func3 == 0b100) {
                // XORI
                return String.format("%s %s, %s, %s", "xori", getRegister(rd), getRegister(rs1), imm);
            } else if (func3 == 0b110) {
                // ORI
                return String.format("%s %s, %s, %s", "ori", getRegister(rd), getRegister(rs1), imm);
            } else if (func3 == 0b111) {
                // ANDI
                return String.format("%s %s, %s, %s", "andi", getRegister(rd), getRegister(rs1), imm);
            } else if (func3 == 0b001 && func7 == 0b0000000) {
                // SLLI
                return String.format("%s %s, %s, %s", "slli", getRegister(rd), getRegister(rs1), shamt);
            } else if (func3 == 0b101) {
                if (func7 == 0b0000000) {
                    // SRLI
                    return String.format("%s %s, %s, %s", "srli", getRegister(rd), getRegister(rs1), shamt);
                } else if (func7 == 0b0100000) {
                    // SRAI
                    return String.format("%s %s, %s, %s", "srai", getRegister(rd), getRegister(rs1), shamt);
                }
            }
        } else if (opcode == 0b0110011) {
            // ADD SUB SLL SLT SLTU XOR SRL SRA OR AND
            // MUL MULH MULHSU MULHU DIV DIVU REM REMU
            int rd = instruction << 20 >>> 27;
            int rs1 = instruction << 12 >>> 27;
            int rs2 = instruction << 7 >>> 27;
            int func3 = instruction << 17 >>> 29;
            int func7 = instruction >>> 25;
            if (func3 == 0b000) {
                if (func7 == 0b0000000) {
                    // ADD
                    return String.format("%s %s, %s, %s", "add", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0100000) {
                    // SUB
                    return String.format("%s %s, %s, %s", "sub", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0000001) {
                    // MUL
                    return String.format("%s %s, %s, %s", "mul", getRegister(rd), getRegister(rs1), getRegister(rs2));
                }
            } else if (func3 == 0b001) {
                if (func7 == 0b0000000) {
                    // SLL
                    return String.format("%s %s, %s, %s", "sll", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0000001) {
                    // MULH
                    return String.format("%s %s, %s, %s", "mulh", getRegister(rd), getRegister(rs1), getRegister(rs2));
                }
            } else if (func3 == 0b010) {
                if (func7 == 0b0000000) {
                    // SLT
                    return String.format("%s %s, %s, %s", "slt", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0000001) {
                    // MULHSU
                    return String.format("%s %s, %s, %s", "mulhsu", getRegister(rd), getRegister(rs1), getRegister(rs2));
                }
            } else if (func3 == 0b011) {
                if (func7 == 0b0000000) {
                    // SLTU
                    return String.format("%s %s, %s, %s", "sltu", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0000001) {
                    // MULHU
                    return String.format("%s %s, %s, %s", "mulhu", getRegister(rd), getRegister(rs1), getRegister(rs2));
                }
            } else if (func3 == 0b100) {
                if (func7 == 0b0000000) {
                    // XOR
                    return String.format("%s %s, %s, %s", "xor", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0000001) {
                    // DIV
                    return String.format("%s %s, %s, %s", "div", getRegister(rd), getRegister(rs1), getRegister(rs2));
                }
            } else if (func3 == 0b101) {
                if (func7 == 0b0000000) {
                    // SRL
                    return String.format("%s %s, %s, %s", "srl", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0100000) {
                    // SRA
                    return String.format("%s %s, %s, %s", "sra", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0000001) {
                    // DIVU
                    return String.format("%s %s, %s, %s", "divu", getRegister(rd), getRegister(rs1), getRegister(rs2));
                }
            } else if (func3 == 0b110) {
                if (func7 == 0b0000000) {
                    // OR
                    return String.format("%s %s, %s, %s", "or", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0000001) {
                    // REM
                    return String.format("%s %s, %s, %s", "rem", getRegister(rd), getRegister(rs1), getRegister(rs2));
                }
            } else if (func3 == 0b111) {
                if (func7 == 0b0000000) {
                    // AND
                    return String.format("%s %s, %s, %s", "and", getRegister(rd), getRegister(rs1), getRegister(rs2));
                } else if (func7 == 0b0000001) {
                    // REMU
                    return String.format("%s %s, %s, %s", "remu", getRegister(rd), getRegister(rs1), getRegister(rs2));
                }
            }
        } else if (opcode == 0b0001111) {
            // skip FENCE FENCE.I
        } else if (opcode == 0b1110011) {
            // ECALL EBREAK CSRRW CSRRS CSRRC CSRRWI CSRRSI CSRRCI
            int func3 = instruction << 17 >>> 29;
            int rd = instruction << 20 >>> 27;
            int rs1 = instruction << 12 >>> 27;
            int func12 = instruction >>> 20;
            long uimm = (long) instruction << 12 >>> 27;
            int csr = func12;
            if (func3 == 0b000) {
                if (rd == 0b00000 && rs1 == 0b00000) {
                    if (func12 == 0b000000000000) {
                        // ECALL
                        return "ecall";
                    } else if (func12 == 0b000000000001) {
                        // EBREAK
                        return "ebreak";
                    }
                }
            } else {
                return switch (func3) {
                    case 0b001 -> String.format("%s %s, %s, %s", "csrrw", getRegister(rd), csr, getRegister(rs1)); // CSRRW
                    case 0b010 -> String.format("%s %s, %s, %s", "csrrs", getRegister(rd), csr, getRegister(rs1)); // CSRRS
                    case 0b011 -> String.format("%s %s, %s, %s", "csrrc", getRegister(rd), csr, getRegister(rs1)); // CSRRC
                    case 0b101 -> String.format("%s %s, %s, %s", "csrrwi", getRegister(rd), csr, uimm); // CSRRWI
                    case 0b110 -> String.format("%s %s, %s, %s", "csrrsi", getRegister(rd), csr, uimm); // CSRRSI
                    case 0b111 -> String.format("%s %s, %s, %s", "csrrci", getRegister(rd), csr, uimm); // CSRRCI
                    default -> "unknown_command";
                };
            }
        }
        return "unknown_command";
    }

    private int read16bit() throws IOException {
        return reader.read() + reader.read() * 0x100;
    }

    private int read32bit() throws IOException {
        return reader.read() + reader.read() * 0x100 + reader.read() * 0x10000 + reader.read() * 0x1000000;
    }

    private String getRegister(int reg) {
        if (reg < 0 || reg > REGISTERS.length) {
            throw new AssertionError("Register " + reg + " does not exist");
        }
        return REGISTERS[reg];
    }

    private String getC_Register(int regc) {
        return getRegister(8 + regc);
    }
}
